<?php

require('api.php');


// Fonction appelée au début du jeu
function init_jeu()
{
    // TODO
}

// Fonction appelée au début du tour
function jouer_tour()
{
    // TODO
}

// Fonction appelée lors du choix entre les trois cartes lors de l'action de
// l'adversaire (cf tour_precedent)
function repondre_action_choix_trois()
{
    // TODO
}

// Fonction appelée lors du choix entre deux paquet lors de l'action de
// l'adversaire (cf tour_precedent)
function repondre_action_choix_paquets()
{
    // TODO
}

// Fonction appelée à la fin du jeu
function fin_jeu()
{
    // TODO
}
