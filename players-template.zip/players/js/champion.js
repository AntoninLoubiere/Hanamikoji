/**
 * Fonction appelée au début du jeu
 */
function initJeu() {}

/**
 * Fonction appelée au début du tour
 */
function jouerTour() {}

/**
 * Fonction appelée lors du choix entre les trois cartes lors de l'action de
 * l'adversaire (cf tour_precedent)
 */
function repondreActionChoixTrois() {}

/**
 * Fonction appelée lors du choix entre deux paquet lors de l'action de
 * l'adversaire (cf tour_precedent)
 */
function repondreActionChoixPaquets() {}

/**
 * Fonction appelée à la fin du jeu
 */
function finJeu() {}

