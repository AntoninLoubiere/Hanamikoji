using System;

namespace Champion {
    class Champion {


        // Fonction appelée au début du jeu
        void InitJeu()
        {
            // TODO
        }

        // Fonction appelée au début du tour
        void JouerTour()
        {
            // TODO
        }

        // Fonction appelée lors du choix entre les trois cartes lors de l'action de
// l'adversaire (cf tour_precedent)
        void RepondreActionChoixTrois()
        {
            // TODO
        }

        // Fonction appelée lors du choix entre deux paquet lors de l'action de
// l'adversaire (cf tour_precedent)
        void RepondreActionChoixPaquets()
        {
            // TODO
        }

        // Fonction appelée à la fin du jeu
        void FinJeu()
        {
            // TODO
        }
    }
}
